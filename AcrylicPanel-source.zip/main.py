import sys
import os
import ctypes
import urllib.parse
import webbrowser
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QSlider, QLineEdit, QMessageBox, QCalendarWidget, QDialog
)

APP_NAME = "AcrylicPanel"

def apply_acrylic(hwnd):
    """Best-effort Windows 10 acrylic blur; translucent fallback is used if unavailable."""
    try:
        class ACCENT_POLICY(ctypes.Structure):
            _fields_ = [("AccentState", ctypes.c_int), ("AccentFlags", ctypes.c_int),
                        ("GradientColor", ctypes.c_uint), ("AnimationId", ctypes.c_int)]
        class WINDOWCOMPOSITIONATTRIBDATA(ctypes.Structure):
            _fields_ = [("Attribute", ctypes.c_int), ("Data", ctypes.c_void_p),
                        ("SizeOfData", ctypes.c_size_t)]
        accent = ACCENT_POLICY(4, 2, 0xD020242C, 0)
        data = WINDOWCOMPOSITIONATTRIBDATA(19, ctypes.addressof(accent), ctypes.sizeof(accent))
        ctypes.windll.user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
    except Exception:
        pass

class Panel(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AcrylicPanel — панель")
        self.setFixedWidth(365)
        self.setMinimumHeight(620)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("""
            QWidget { color:#f5f7fa; font-family:'Segoe UI'; }
            QFrame#surface { background:rgba(28,33,42,232); border:1px solid rgba(255,255,255,35); border-radius:22px; }
            QLabel#clock { font-size:42px; font-weight:300; }
            QLabel#date { color:#cbd2dc; font-size:13px; }
            QPushButton { background:rgba(255,255,255,24); border:1px solid rgba(255,255,255,28); border-radius:12px; padding:12px 8px; font-size:12px; }
            QPushButton:hover { background:rgba(255,255,255,48); }
            QPushButton:checked { background:#426da9; }
            QLineEdit { background:rgba(255,255,255,20); border:1px solid rgba(255,255,255,35); border-radius:12px; padding:11px; color:white; }
            QSlider::groove:horizontal { height:5px; background:rgba(255,255,255,55); border-radius:2px; }
            QSlider::handle:horizontal { background:white; width:14px; margin:-5px 0; border-radius:7px; }
        """)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        surface = QFrame()
        surface.setObjectName("surface")
        outer.addWidget(surface)
        layout = QVBoxLayout(surface)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)

        top = QHBoxLayout()
        self.clock = QLabel()
        self.clock.setObjectName("clock")
        top.addWidget(self.clock)
        top.addStretch()
        close = QPushButton("✕")
        close.setFixedSize(36, 36)
        close.clicked.connect(self.hide)
        top.addWidget(close)
        layout.addLayout(top)
        self.date_label = QLabel()
        self.date_label.setObjectName("date")
        layout.addWidget(self.date_label)
        self.update_clock()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_clock)
        self.timer.start(1000)

        layout.addWidget(self.heading("Быстрые настройки"))
        for names in (("Wi-Fi", "Bluetooth", "Режим полёта"),
                      ("Экономия", "Ночной свет", "Фокус")):
            row = QHBoxLayout()
            for name in names:
                b = QPushButton(name)
                b.setCheckable(True)
                b.setMinimumHeight(55)
                b.clicked.connect(lambda checked, btn=b, title=name:
                                  btn.setText(("✓ " if checked else "") + title))
                row.addWidget(b)
            layout.addLayout(row)

        layout.addWidget(self.heading("Звук"))
        self.add_slider(layout, "Громкость", 65)
        layout.addWidget(self.heading("Яркость"))
        self.add_slider(layout, "Яркость экрана", 80)

        search = QLineEdit()
        search.setPlaceholderText("Поиск в интернете…")
        search.returnPressed.connect(lambda: self.search(search.text()))
        layout.addWidget(search)

        row = QHBoxLayout()
        for label, action in (("Переводчик", self.translator),
                              ("Календарь", self.calendar)):
            b = QPushButton(label)
            b.clicked.connect(action)
            row.addWidget(b)
        layout.addLayout(row)
        settings = QPushButton("Параметры Windows")
        settings.clicked.connect(self.settings)
        layout.addWidget(settings)
        layout.addStretch()

    def heading(self, text):
        label = QLabel(text)
        label.setStyleSheet("font-size:15px;font-weight:600;color:#e9edf4;")
        return label

    def add_slider(self, layout, title, initial):
        row = QHBoxLayout()
        row.addWidget(QLabel(title))
        value = QLabel(f"{initial}%")
        row.addWidget(value)
        layout.addLayout(row)
        slider = QSlider(Qt.Horizontal)
        slider.setRange(0, 100)
        slider.setValue(initial)
        slider.valueChanged.connect(lambda v: value.setText(f"{v}%"))
        layout.addWidget(slider)

    def update_clock(self):
        now = datetime.now()
        self.clock.setText(now.strftime("%H:%M"))
        self.date_label.setText(now.strftime("%d.%m.%Y"))

    def search(self, text):
        if text.strip():
            webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(text))

    def translator(self):
        webbrowser.open("https://translate.google.com/")

    def calendar(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Календарь")
        dialog.setStyleSheet("background:#252b35;color:white;")
        box = QVBoxLayout(dialog)
        box.addWidget(QCalendarWidget())
        dialog.resize(330, 300)
        dialog.exec()

    def settings(self):
        try:
            os.startfile("ms-settings:")
        except Exception:
            pass

    def showEvent(self, event):
        super().showEvent(event)
        if sys.platform == "win32":
            apply_acrylic(int(self.winId()))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton and hasattr(self, "drag_offset"):
            self.move(event.globalPosition().toPoint() - self.drag_offset)
            event.accept()

class Controller(QWidget):
    def __init__(self):
        super().__init__()
        self.panel = Panel()
        self.setWindowTitle("AcrylicPanel — управление")
        self.setFixedSize(330, 205)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowMaximizeButtonHint)
        self.setStyleSheet("""
            QWidget { background:#202630; color:#f4f6fa; font-family:'Segoe UI'; }
            QLabel { color:#f4f6fa; }
            QPushButton { background:#344253; color:white; border:0; border-radius:12px; padding:14px; font-size:15px; }
            QPushButton:hover { background:#49617c; }
            QPushButton#on { background:#287a50; }
            QPushButton#off { background:#8b3b42; }
        """)
        layout = QVBoxLayout(self)
        title = QLabel("AcrylicPanel")
        title.setStyleSheet("font-size:22px;font-weight:600;")
        layout.addWidget(title)
        layout.addWidget(QLabel("Управление боковой панелью"))
        on = QPushButton("ВКЛЮЧИТЬ")
        on.setObjectName("on")
        on.clicked.connect(self.show_panel)
        off = QPushButton("ВЫКЛЮЧИТЬ")
        off.setObjectName("off")
        off.clicked.connect(self.hide_panel)
        layout.addWidget(on)
        layout.addWidget(off)

    def show_panel(self):
        screen = QApplication.primaryScreen().availableGeometry()
        self.panel.move(screen.right() - self.panel.width() + 1, screen.top() + 35)
        self.panel.show()
        self.panel.raise_()

    def hide_panel(self):
        self.panel.hide()

    def closeEvent(self, event):
        self.panel.hide()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    controller = Controller()
    controller.show()
    sys.exit(app.exec())
